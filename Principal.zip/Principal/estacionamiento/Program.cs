﻿using System;
using System.Collections.Generic;
using BLL;
using System.Text;
using System.Threading.Tasks;

namespace estacionamiento
{
    class Program
    {
        static void Main(string[] args)
        {
            VehiculoBLL vehiculoBLL = new VehiculoBLL();

            Console.WriteLine("Ingrese el nombre del vehículo: ");
            string nombre = Console.ReadLine();

            Console.WriteLine("Ingrese la placa del vehículo: ");
            string placa = Console.ReadLine();

            vehiculoBLL.IngresarVehiculo(nombre, placa);

            Console.WriteLine("Vehículo ingresado con éxito.");

            Console.WriteLine("Ingrese la placa del vehículo para calcular la tarifa: ");
            placa = Console.ReadLine();

            double tarifa = vehiculoBLL.CalcularTarifa(placa);

            if (tarifa > 0)
            {
                Console.WriteLine($"La tarifa a pagar es: ${tarifa}");
            }
            else
            {
                Console.WriteLine("El vehículo no se encuentra en el estacionamiento.");
            }
        }
    }

}
