﻿using System;
using System.Collections.Generic;
using System.Linq;
using ENTITY;
using System.Threading.Tasks;
using System.IO;

namespace DAL
{
    public class VehiculoRepositorio : AmdConsola
    {
        public VehiculoRepositorio(string fileName) : base(fileName)
        {

        }
        public List<Vehiculo> ConsultarVehiculos()
        {
            try
            {
                List<Vehiculo> lista = new List<Vehiculo>();
                StreamReader sr = new StreamReader(fileName);
                while (!sr.EndOfStream)
                {
                    lista.Add(Mapear(sr.ReadLine()));

                }
                sr.Close();
                return lista;
            }

            catch (Exception)
            {
                return null;
            }
        }

        private Vehiculo Mapear(string datos)
        {
            var linea = datos.Split(';');
            Vehiculo vehiculo = new Vehiculo
            {
                Placa = linea[0],
                Cliente = linea[1],
                Color = linea[2],
                TipoVehiculo = linea[3],

            };
            return vehiculo;
        }
        




    }
}



