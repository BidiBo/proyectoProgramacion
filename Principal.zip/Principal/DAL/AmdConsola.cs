﻿using ENTITY;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class AmdConsola
    {
        protected string fileName;
        public AmdConsola(string fileName)
        {
            this.fileName = fileName;
        }
        public string Guardar(string datos)
        {
            StreamWriter sw = new StreamWriter(fileName, true);
            sw.WriteLine(datos);
            sw.Close();
            return "datos guardados";
        }
        public string Eliminar(string placa)
        {
            try
            {
                List<string> lines = File.ReadAllLines(fileName).ToList();
                List<string> updatedLines = new List<string>();
                bool vehiculoEncontrado = false;

                foreach (string line in lines)
                {
                    Vehiculo vehiculo = Vehiculo.Parse(line);
                    if (vehiculo != null && vehiculo.Placa != placa)
                    {
                        updatedLines.Add(line);
                    }
                    else
                    {
                        vehiculoEncontrado = true;
                    }
                }

                if (vehiculoEncontrado)
                {
                    File.WriteAllLines(fileName, updatedLines);
                    return "Vehículo eliminado.";
                }
                else
                {
                    return "No se encontró un vehículo con la placa especificada.";
                }
            }
            catch (Exception ex)
            {
                return "Error al eliminar el vehículo: " + ex.Message;
            }
        }
        public string Modificar(string placa, Vehiculo nuevoVehiculo)
        {
            try
            {
                List<string> lines = File.ReadAllLines(fileName).ToList();
                List<string> updatedLines = new List<string>();
                bool vehiculoEncontrado = false;

                foreach (string line in lines)
                {
                    Vehiculo vehiculo = Vehiculo.Parse(line);
                    if (vehiculo != null && vehiculo.Placa != placa)
                    {
                        updatedLines.Add(line);
                    }
                    else
                    {
                        vehiculoEncontrado = true;
                        // Aquí debes modificar el vehículo con los nuevos datos
                        updatedLines.Add(nuevoVehiculo.ToString());
                    }
                }

                if (vehiculoEncontrado)
                {
                    File.WriteAllLines(fileName, updatedLines);
                    return "Vehículo modificado.";
                }
                else
                {
                    return "No se encontró un vehículo con la placa especificada.";
                }
            }
            catch (Exception ex)
            {
                return "Error al modificar el vehículo: " + ex.Message;
            }

        }
    }
}

