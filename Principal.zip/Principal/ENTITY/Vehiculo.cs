﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    public class Vehiculo
    {
        public Vehiculo()
        { 

        }
        public Vehiculo(string cliente, string placa, string color, string tipoVehiculo, DateTime horaIngreso, DateTime horaSalida, double tarifa, string estado)
        {
            Cliente = cliente;
            Placa = placa;
            Color = color;
            TipoVehiculo = tipoVehiculo;
            HoraIngreso = horaIngreso;
            HoraSalida = horaSalida;
            Tarifa = tarifa;
            Estado = estado;
        }


        public string Cliente { get; set; }
        public string Placa { get; set; }
        public string Color { get; set; }
        public string TipoVehiculo { get; set; }
        public DateTime HoraIngreso { get; set; }
        public DateTime HoraSalida { get; set; }
        protected double Tarifa { get; set; }
        public string Estado { get; set; }

        public override string ToString()
        {
            return $"{Cliente};{Placa};{Color};{TipoVehiculo};{HoraIngreso};{HoraSalida};{Tarifa};{Estado}";
        }

        public static Vehiculo Parse(string line)
        {
            string[] partes = line.Split(';');
            if (partes.Length == 9)
            {
                string Cliente = partes[0];
                string Placa = partes[1];
                string Color = partes[2];
                string TipoVehiculo = partes[3];
                DateTime HoraIngreso;
                if (DateTime.TryParse(partes[4], out HoraIngreso) == false)
                {
                    throw new FormatException("Formato de fecha HoraIngreso incorrecto.");
                }

                DateTime HoraSalida;
                if (DateTime.TryParse(partes[5], out HoraSalida) == false)
                {
                    throw new FormatException("Formato de fecha HoraSalida incorrecto.");
                }

                double Tarifa;
                if (double.TryParse(partes[6], out Tarifa) == false)
                {
                    throw new FormatException("Formato de tarifa incorrecto.");
                }

                string Estado = partes[7];

                return new Vehiculo(Cliente, Placa, Color, TipoVehiculo, HoraIngreso, HoraSalida, Tarifa, Estado);
            }
            else
            {
                throw new FormatException("Formato de línea incorrecto.");
            }
        }
    }
}




