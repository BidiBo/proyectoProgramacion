﻿using System;
using System.Collections.Generic;
using ENTITY;
using DAL;
using System.Threading.Tasks;
using System.Runtime.Remoting.Messaging;

namespace BLL
{
    public class VehiculoServis
    {
        private string fileName = "Vehiculo.txt ";
        VehiculoRepositorio repositorio;

        private List<Vehiculo> vehiculos;
        public VehiculoServis()
        {
            repositorio = new VehiculoRepositorio(fileName);
            RefrescarLista();
        }
        void RefrescarLista()
        {
            vehiculos = repositorio.ConsultarVehiculos();
            
        }
        public string Guardar(Vehiculo vehiculo)
        {
            var msg = repositorio.Guardar(vehiculo.ToString());

            RefrescarLista();
            return msg;
        }
        public List<Vehiculo> Consultar()
        {
            return vehiculos;
        }
        public string Eliminar(string placa)
        {
            return repositorio.Eliminar(placa); 
        }
        public string Modificar(string placa, Vehiculo nuevoVehiculo)
        {
            return repositorio.Modificar(placa, nuevoVehiculo);
        }





    }
}
