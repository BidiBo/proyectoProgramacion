﻿using System;
using BLL;
using ENTITY;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;

using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Ingresar
{
    public partial class Gestion : Form
    {
        private VehiculoServis vehiculoServis = new VehiculoServis();
        
        
        public Gestion()
        { 
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("¿Desea regresar al menu anterior ?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                this.Hide();
                Ingresar ingresar = new Ingresar();
                ingresar.Show();
            }
        }

        private void GUARDAR1_Click(object sender, EventArgs e)
        {
            string cliente = txtCliente.Text;
            string placa = txtPlaca.Text;
            string color = txtColor.Text;
            string tipoVehiculo = comboBox1.SelectedItem as string;

            
            if (!EsTextoValido(cliente))
            {
                MessageBox.Show("El campo 'Cliente' debe contener solo letras.");
                return;
            }

            
            if (!EsTextoValido(color))
            {
                MessageBox.Show("El campo 'Color' debe contener solo letras.");
                return;
            }

            
            if (!EsFormatoPlacaValido(placa))
            {
                MessageBox.Show("El campo 'Placa' debe tener el formato correcto (LLL 123).");
                return;
            }

            if (string.IsNullOrEmpty(cliente) || string.IsNullOrEmpty(placa) || string.IsNullOrEmpty(color) || string.IsNullOrEmpty(tipoVehiculo))
            {
                MessageBox.Show("Debe llenar todos los campos antes de guardar.");
            }
            else
            {
                cliente = cliente.ToUpper();
                placa = placa.ToUpper();
                color = color.ToUpper();
                Vehiculo vehiculo = new Vehiculo
                {
                    Cliente = cliente,
                    Placa = placa,
                    Color = color,
                    HoraIngreso = DateTime.Now,
                    TipoVehiculo = comboBox1.SelectedItem != null ? comboBox1.SelectedItem.ToString() : "Tipo no especificado"
                };

                txtCliente.Text = "";
                txtPlaca.Text = "";
                txtColor.Text = "";

                Guardar(vehiculo);
            }
        }

        private bool EsTextoValido(string texto)
        {
            
            Regex regex = new Regex("^[a-zA-Z]+$");
            return regex.IsMatch(texto);
        }

        private bool EsFormatoPlacaValido(string placa)
        {
            
            Regex regex = new Regex("^[a-zA-Z]{3} \\d{3}$");
            return regex.IsMatch(placa);
        }
        void Guardar(Vehiculo vehiculo)
        {
            var msg = vehiculoServis.Guardar(vehiculo);
            MessageBox.Show(msg);
        }


        void CargarGrilla(List<Vehiculo> lista)
        {
            grillaVehiculo.Rows.Clear();

            if (lista != null)
            {
                foreach (var item in lista)
                {
                    grillaVehiculo.Rows.Add(
                        item.Placa,
                        item.Cliente,
                        item.Color,
                        item.TipoVehiculo
                    );
                }
            }
        }



        private void CargarDatos()
        {

            CargarVehiculos();
            
        }
        private void CargarVehiculos()
        {
            List<Vehiculo> vehiculos = vehiculoServis.Consultar();
            CargarGrilla(vehiculos);

        }

        private void grillaVehiculo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CargarDatos();
            
        }

        private void ELIMINAR_Click(object sender, EventArgs e)
        {
            
                
                if (grillaVehiculo.SelectedRows.Count > 0)
                {
                    int indiceFila = grillaVehiculo.SelectedRows[0].Index;

                    
                    string placa = grillaVehiculo.Rows[indiceFila].Cells["Placa"].Value.ToString();

                    
                    DialogResult resultado = MessageBox.Show($"¿Desea eliminar el vehículo con la placa: {placa}?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (resultado == DialogResult.Yes)
                    {
                        
                        EliminarVehiculo(placa);

                        
                        CargarDatos();
                    }
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione un vehículo para eliminar.");
            }
        }
        private void EliminarVehiculo(string placa)
        {
            SolicitarEliminar(placa); 
            CargarDatos();
            MessageBox.Show($"El vehículo con placa {placa} ha sido eliminado.");
        }
        public void SolicitarEliminar(string placa)
        {
            var msg = vehiculoServis.Eliminar(placa); 
                                                      
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Gestion_Load(object sender, EventArgs e)
        {
            CargarDatos();
            
            

        }

       
        private void parqueadero_Click(object sender, EventArgs e)
        {
            this.Hide();
            Tarifa tarifa = new Tarifa();
            tarifa.ShowDialog();

        }
    }
}


