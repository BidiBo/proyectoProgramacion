﻿using BLL;
using ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ingresar
{
    public partial class Tarifa : Form
    {
        private VehiculoServis vehiculoServis = new VehiculoServis();
        public Tarifa()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void REGRESAR_Click(object sender, EventArgs e)
        {
            this.Hide();
            Gestion gestion = new Gestion();
            gestion.ShowDialog();
        }

        private void grillaVehiculo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CargarDatos();
        }
        private void CargarDatos()
        {

            CargarVehiculos();

        }
        private void CargarVehiculos()
        {
            List<Vehiculo> vehiculos = vehiculoServis.Consultar();
            CargarGrilla(vehiculos);

        }
        void CargarGrilla(List<Vehiculo> lista)
        {
            grillaVehiculo.Rows.Clear();

            if (lista != null)
            {
                foreach (var item in lista)
                {
                    grillaVehiculo.Rows.Add(
                        item.Placa,
                        item.Cliente,
                        item.Color,
                        item.TipoVehiculo
                    );
                }
            }
        }
    }
}
