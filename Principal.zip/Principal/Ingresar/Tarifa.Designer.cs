﻿namespace Ingresar
{
    partial class Tarifa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tarifa));
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.REGRESAR = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.grillaVehiculo = new System.Windows.Forms.DataGridView();
            this.CLIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PLACA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COLOR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIPO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ESTADO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HORAINGRESO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.grillaVehiculo)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(355, 46);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(139, 36);
            this.button2.TabIndex = 1;
            this.button2.Text = "CALCULAR TARIFA";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(30, 46);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "BUSCAR PLACA";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // REGRESAR
            // 
            this.REGRESAR.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.REGRESAR.Image = ((System.Drawing.Image)(resources.GetObject("REGRESAR.Image")));
            this.REGRESAR.Location = new System.Drawing.Point(564, 41);
            this.REGRESAR.Name = "REGRESAR";
            this.REGRESAR.Size = new System.Drawing.Size(111, 46);
            this.REGRESAR.TabIndex = 2;
            this.REGRESAR.Text = "REGRESAR";
            this.REGRESAR.UseVisualStyleBackColor = true;
            this.REGRESAR.Click += new System.EventHandler(this.REGRESAR_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(158, 62);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(159, 20);
            this.textBox1.TabIndex = 3;
            // 
            // grillaVehiculo
            // 
            this.grillaVehiculo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaVehiculo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CLIENTE,
            this.PLACA,
            this.COLOR,
            this.TIPO,
            this.ESTADO,
            this.HORAINGRESO,
            this.TA});
            this.grillaVehiculo.Location = new System.Drawing.Point(30, 115);
            this.grillaVehiculo.Name = "grillaVehiculo";
            this.grillaVehiculo.Size = new System.Drawing.Size(645, 147);
            this.grillaVehiculo.TabIndex = 4;
            this.grillaVehiculo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grillaVehiculo_CellContentClick);
            // 
            // CLIENTE
            // 
            this.CLIENTE.HeaderText = "CLIENTE";
            this.CLIENTE.Name = "CLIENTE";
            this.CLIENTE.Visible = false;
            // 
            // PLACA
            // 
            this.PLACA.HeaderText = "PLACA";
            this.PLACA.Name = "PLACA";
            // 
            // COLOR
            // 
            this.COLOR.HeaderText = "COLOR";
            this.COLOR.Name = "COLOR";
            // 
            // TIPO
            // 
            this.TIPO.HeaderText = "TIPO DE VEHICULO";
            this.TIPO.Name = "TIPO";
            // 
            // ESTADO
            // 
            this.ESTADO.HeaderText = "ESTADO";
            this.ESTADO.Name = "ESTADO";
            // 
            // HORAINGRESO
            // 
            this.HORAINGRESO.HeaderText = "HORA DE INGRESO";
            this.HORAINGRESO.Name = "HORAINGRESO";
            // 
            // TA
            // 
            this.TA.HeaderText = "TARIFA";
            this.TA.Name = "TA";
            // 
            // Tarifa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grillaVehiculo);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.REGRESAR);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Tarifa";
            this.Text = "Tarifa";
            ((System.ComponentModel.ISupportInitialize)(this.grillaVehiculo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button REGRESAR;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView grillaVehiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CLIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn PLACA;
        private System.Windows.Forms.DataGridViewTextBoxColumn COLOR;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIPO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ESTADO;
        private System.Windows.Forms.DataGridViewTextBoxColumn HORAINGRESO;
        private System.Windows.Forms.DataGridViewTextBoxColumn TA;
    }
}